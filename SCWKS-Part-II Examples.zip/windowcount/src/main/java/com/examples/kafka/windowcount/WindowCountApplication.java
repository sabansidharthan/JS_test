package com.examples.kafka.windowcount;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WindowCountApplication {

	public static void main(String[] args) {
		SpringApplication.run(WindowCountApplication.class, args);
	}

}
