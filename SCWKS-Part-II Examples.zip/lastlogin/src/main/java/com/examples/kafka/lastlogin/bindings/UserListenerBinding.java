package com.examples.kafka.lastlogin.bindings;

import org.apache.kafka.streams.kstream.KTable;
import org.springframework.cloud.stream.annotation.Input;

import com.examples.kafka.lastlogin.model.UserDetails;
import com.examples.kafka.lastlogin.model.UserLogin;

public interface UserListenerBinding {

    @Input("user-master-channel")
    KTable<String, UserDetails> userInputStream();

    @Input("user-login-channel")
    KTable<String, UserLogin> loginInputStream();

}
