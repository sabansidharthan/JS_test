package com.examples.kafka.sessionwindow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SessionWindowApplication {

	public static void main(String[] args) {
		SpringApplication.run(SessionWindowApplication.class, args);
	}

}
