package com.examples.kafka.otpvalidation.services;


import lombok.extern.log4j.Log4j2;
import org.springframework.stereotype.Service;

import com.examples.kafka.otpvalidation.model.PaymentConfirmation;
import com.examples.kafka.otpvalidation.model.PaymentRequest;
import com.examples.kafka.otpvalidation.model.TransactionStatus;

@Service
@Log4j2
public class RecordBuilder {
    public TransactionStatus getTransactionStatus(PaymentRequest request, PaymentConfirmation confirmation){
        String status = "Failure";
        if(request.getOTP().equals(confirmation.getOTP()))
            status = "Success";

        TransactionStatus transactionStatus = new TransactionStatus();
        transactionStatus.setTransactionID(request.getTransactionID());
        transactionStatus.setStatus(status);
        return transactionStatus;
    }
}
