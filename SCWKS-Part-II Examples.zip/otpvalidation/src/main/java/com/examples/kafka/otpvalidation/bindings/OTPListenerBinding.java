package com.examples.kafka.otpvalidation.bindings;

import org.apache.kafka.streams.kstream.KStream;
import org.springframework.cloud.stream.annotation.Input;

import com.examples.kafka.otpvalidation.model.PaymentConfirmation;
import com.examples.kafka.otpvalidation.model.PaymentRequest;

public interface OTPListenerBinding {

    @Input("payment-request-channel")
    KStream<String, PaymentRequest> requestInputStream();

    @Input("payment-confirmation-channel")
    KStream<String, PaymentConfirmation> confirmationInputStream();

}
